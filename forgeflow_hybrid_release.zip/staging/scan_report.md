# ForgeFlow Report: SCAN

**Date:** 2026-02-09T03:34:39.295319
**Status:** warning
**Server:** security-mcp-server
**Mode:** local

## Summary

Found 6 security issues

## Findings

- MEDIUM: agents/generation_agent.py:1408 - Debug mode enabled
- CRITICAL: tests/conftest.py:54 - Hardcoded password
- CRITICAL: tests/conftest.py:55 - Hardcoded API key
- HIGH: tests/conftest.py:59 - Command injection via os.system
- HIGH: tests/conftest.py:60 - Shell injection risk
- HIGH: tests/conftest.py:64 - SQL in f-string

## Data

```json
{
  "total": 6,
  "by_severity": {
    "medium": 1,
    "critical": 2,
    "high": 3
  },
  "threshold": "medium",
  "vulnerabilities": [
    {
      "severity": "medium",
      "type": "insecure-config",
      "file": "agents/generation_agent.py",
      "line": 1408,
      "issue": "Debug mode enabled",
      "snippet": "- DEBUG=true"
    },
    {
      "severity": "critical",
      "type": "hardcoded-secret",
      "file": "tests/conftest.py",
      "line": 54,
      "issue": "Hardcoded password",
      "snippet": "password = \"super_secret_123\""
    },
    {
      "severity": "critical",
      "type": "hardcoded-secret",
      "file": "tests/conftest.py",
      "line": 55,
      "issue": "Hardcoded API key",
      "snippet": "api_key = \"sk-12345678901234567890\""
    },
    {
      "severity": "high",
      "type": "command-injection",
      "file": "tests/conftest.py",
      "line": 59,
      "issue": "Command injection via os.system",
      "snippet": "os.system(\"ls \" + user_input)"
    },
    {
      "severity": "high",
      "type": "command-injection",
      "file": "tests/conftest.py",
      "line": 60,
      "issue": "Shell injection risk",
      "snippet": "subprocess.call(user_input, shell=True)"
    },
    {
      "severity": "high",
      "type": "sql-injection",
      "file": "tests/conftest.py",
      "line": 64,
      "issue": "SQL in f-string",
      "snippet": "query = f\"SELECT * FROM users WHERE id = {user_input}\""
    }
  ]
}
```
