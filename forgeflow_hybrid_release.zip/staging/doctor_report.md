# ForgeFlow Report: DOCTOR

**Date:** 2026-02-09T03:33:54.598735
**Status:** success
**Server:** internal
**Mode:** local

## Summary

Checked 15 components (mode: local)

## Findings

- OK: deployment_mode
- OK: mcp-config.yaml
- OK: forgeflow-config.yaml
- OK: discovery-mcp-server
- OK: normalize-mcp-server
- OK: security-mcp-server
- OK: deployment-mcp-server
- OK: cloud-mcp-server
- OK: cicd-mcp-server
- OK: observability-mcp-server
- OK: diagram-generator-mcp-server
- OK: git-mcp-server
- OK: github-mcp-server
- OK: command_mapping
- OK: pipeline_config

## Data

```json
{
  "health": [
    {
      "component": "deployment_mode",
      "status": "OK",
      "details": "LOCAL"
    },
    {
      "component": "mcp-config.yaml",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp-config.yaml"
    },
    {
      "component": "forgeflow-config.yaml",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/config/forgeflow-config.yaml"
    },
    {
      "component": "discovery-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/discovery_mcp/server.py"
    },
    {
      "component": "normalize-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/normalize_mcp/server.py"
    },
    {
      "component": "security-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/security_mcp/server.py"
    },
    {
      "component": "deployment-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/deployment_mcp/server.py"
    },
    {
      "component": "cloud-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/cloud_mcp/server.py"
    },
    {
      "component": "cicd-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/cicd_mcp/server.py"
    },
    {
      "component": "observability-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/observability_mcp/server.py"
    },
    {
      "component": "diagram-generator-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/diagram_generator_mcp/server.py"
    },
    {
      "component": "git-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/git_mcp/server.py"
    },
    {
      "component": "github-mcp-server",
      "status": "OK",
      "details": "/home/ubuntu/forgeflow/mcp_servers/github_mcp/server.py"
    },
    {
      "component": "command_mapping",
      "status": "OK",
      "details": "10 commands mapped"
    },
    {
      "component": "pipeline_config",
      "status": "OK",
      "details": "2 pipelines defined"
    }
  ]
}
```
